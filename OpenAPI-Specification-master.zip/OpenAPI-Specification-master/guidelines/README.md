## Guidelines for Swagger definitions

* [Reuse](REUSE.md) of Swagger definitions
* [Extending](EXTENSIONS.md) Swagger definitions with custom metadata
